import React from 'react';

function ContactPage() {
  return (
    <div>
      <h2>Contact Page</h2>
      <p>This is the Contact Page content.</p>
    </div>
  );
}

export default ContactPage;
