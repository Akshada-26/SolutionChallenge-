import React from 'react';

function AboutPage() {
  return (
    <div>
      <h2>About Page</h2>
      <p>This is the About Page content.</p>
    </div>
  );
}

export default AboutPage;
